/* Challenges:

Formatting the picture 
Alignments 
Organization


Learn to design most of the code from W3school

Choose this Ai generated picture due to interests in Ai's future and plus I like how I'm usually techincal but, I'm getting more creative as the years come
*/